package org.ctdworld.appraise.activity;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import org.ctdworld.appraise.R;

public class SplashActivity extends AppCompatActivity
{

    private static final int SPLASH_TIME = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        animate();

        new Handler().postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                startActivity(new Intent(SplashActivity.this, LoginSocialActivity.class));
                finish();
            }
        },SPLASH_TIME);

    }


    private void animate()
    {
        final ImageView imgLogo = findViewById(R.id.img_logo);
        ImageView imgBg = findViewById(R.id.img_bg_main);

        final Animation animLogo = AnimationUtils.loadAnimation(this,R.anim.anim_logo);
        Animation animBg = AnimationUtils.loadAnimation(this,R.anim.anim_bg_image);

        imgBg.setAnimation(animBg);



        animBg.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imgLogo.setVisibility(View.VISIBLE);
                imgLogo.setAnimation(animLogo);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


    }
}
