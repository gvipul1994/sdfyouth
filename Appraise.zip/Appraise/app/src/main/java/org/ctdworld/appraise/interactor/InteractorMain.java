package org.ctdworld.appraise.interactor;

import android.content.Context;
import android.net.Uri;

import org.ctdworld.appraise.bean.User;
import org.ctdworld.appraise.contract.ContractMain;
import org.ctdworld.appraise.helpers.PreferenceHelper;

public class InteractorMain implements ContractMain.Interacter
{

    ContractMain.Interacter.OnFinishedListener mListener;
    Context mContext;

    public InteractorMain(Context mContext, OnFinishedListener mListener) {
        this.mListener = mListener;
        this.mContext = mContext;
    }

    @Override
    public void updateNavigationDrawerUi()
    {
        User user = PreferenceHelper.getUserDetails(mContext);
        mListener.updateNavigationDrawerUi(user.getName(),user.getEmail(), user.getPicUri());
    }
}
