package org.ctdworld.appraise.presenter;

import android.content.Context;
import android.net.Uri;

import org.ctdworld.appraise.contract.ContractMain;
import org.ctdworld.appraise.interactor.InteractorMain;

public class PresenterMain implements ContractMain.Presenter, ContractMain.Interacter.OnFinishedListener
{
    ContractMain.View mListener;
    ContractMain.Interacter mInteracter;

    public PresenterMain(Context context, ContractMain.View listener)
    {
        this.mListener = listener;
        mInteracter = new InteractorMain(context,this);
    }

    @Override
    public void updateNavigationDrawerUi()
    {
        mInteracter.updateNavigationDrawerUi();
    }

    @Override
    public void updateNavigationDrawerUi(String name, String email, String picUri) {
        mListener.updateNavigationDrawerUi(name,email,picUri);
    }

    @Override
    public void logOut() {
        mListener.logOut();
    }
}
