package org.ctdworld.appraise.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.ctdworld.appraise.R;
import org.ctdworld.appraise.helpers.UtilHelper;

public class ActivityForgotPassword extends AppCompatActivity
{
    private static final String TAG = ActivityForgotPassword.class.getSimpleName();

    EditText mEditEmail;
    Button mBtnLogin;
    String mDialogTile = "Wait....", mDialogMessage = "Coming soon";
    Context mContext = this;
    Toolbar mToolbar;
    TextView mToolbarTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        try
        {
            setContentView(R.layout.activity_forgot_password);
            init();
            setToolbar();
            setListeners();

        }
        catch(Exception e)
        {
            Log.i(TAG,"Error in onCreate() method , "+e.getMessage());
            e.printStackTrace();
        }
    }


    private void init()
    {
        mEditEmail = findViewById(R.id.edit_email);
        mBtnLogin = findViewById(R.id.btn_login);
        mToolbar = findViewById(R.id.toolbar);
        mToolbarTitle = findViewById(R.id.toolbar_txt_title);
    }


    private void setToolbar() {
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        mToolbarTitle.setText("Forgot Password");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
    }

    private void setListeners()
    {
        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  UtilHelper.showSimpleDialog(context,dialogTile,dialogMessage);
                startActivity(new Intent(ActivityForgotPassword.this,MainActivity.class));
            }
        });
    }

}
