package org.ctdworld.appraise.helpers;

public class Const
{
    public class Tag
    {
        public static final String FRAGMENT_NAVIGATION_DRAWER = "navigation drawer";
    }
}
