package org.ctdworld.appraise.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookActivity;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.LoggingBehavior;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.internal.CallbackManagerImpl;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;

import org.ctdworld.appraise.R;
import org.ctdworld.appraise.bean.User;
import org.ctdworld.appraise.helpers.PreferenceHelper;
import org.ctdworld.appraise.helpers.UtilHelper;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import bolts.Task;

public class LoginSocialActivity extends AppCompatActivity
{
    private static final String TAG = LoginSocialActivity.class.getSimpleName();
    Button mBtnLogin, mBtnSignUp;
    ImageView mImgFacebook, mImgTwitter, mImgGoogle;
    Context mContext = this;
    String dialogTitle = "Wait...", dialogMessage = "Coming soon";
    ProgressDialog mProgressDialog;


    // facebook
    CallbackManager mFacebookCallbackManager;
    ProfileTracker mFacebookProfileTracker;
    LoginManager mFacebookLoginManager;


    // google
    GoogleApiClient  mGoogleApiClient;
    private static final int REQUEST_CODE_GOOGLE = 500;


    @Override
    protected void onStart() {
        super.onStart();

        GoogleSignInAccount signInAccount = GoogleSignIn.getLastSignedInAccount(this);
        if (signInAccount != null) {
            Log.i(TAG, "Already logged in with google account ");
            changeActivity();
        }
        else
            Log.i(TAG,"not logged in with google account ");


        /*OptionalPendingResult<GoogleSignInResult> opr = Auth.GoogleSignInApi.silentSignIn(mGoogleApiClient);
        if (opr.isDone()) {
            // If the user's cached credentials are valid, the OptionalPendingResult will be "done"
            // and the GoogleSignInResult will be available instantly. We can try and retrieve an
            // authentication code.
            Log.d(TAG, "Got cached sign-in");
            GoogleSignInResult result = opr.get();
            handleGoogleLoginResult(result);
        } else {
            // If the user has not previously signed in on this device or the sign-in has expired,
            // this asynchronous branch will attempt to sign in the user silently.  Cross-device
            // single sign-on will occur in this branch.
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Checking sign in state...");
            progressDialog.show();
            opr.setResultCallback(new ResultCallback<GoogleSignInResult>() {
                @Override
                public void onResult(@NonNull GoogleSignInResult googleSignInResult) {
                    progressDialog.dismiss();
                    handleGoogleLoginResult(googleSignInResult);
                }
            });
        }*/



        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        if (accessToken == null)
            Log.i(TAG,"not logged in with facebook");
        else {
            Log.i(TAG, "logged in with facebook");
            changeActivity();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        try
        {
            setContentView(R.layout.activity_login_social);
            configureFacebookLogin();
            configureGoogleLogin();
            init();
            setListers();
         }
        catch (Exception e)
        {
            Log.e(TAG,"Error in onCreate() method , "+e.getMessage());
            e.printStackTrace();
        }

    }

    private void setListers()
    {
        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginSocialActivity.this, LoginActivity.class));
            }
        });


        mBtnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // UtilHelper.showSimpleDialog(mContext,dialogTitle,dialogMessage);
                startActivity(new Intent(mContext,ActivityRegister.class));
            }
        });


        mImgFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             //   UtilHelper.showSimpleDialog(context,dialogTitle,dialogMessage);

              loginWithFacebook();
            }
        });

        mImgTwitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UtilHelper.showSimpleDialog(mContext,dialogTitle,dialogMessage);
            }
        });


        mImgGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  UtilHelper.showSimpleDialog(context,dialogTitle,dialogMessage);
                mProgressDialog.show();
                Intent googleIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
                startActivityForResult(googleIntent,REQUEST_CODE_GOOGLE);
            }
        });

    }

    private void init() {
       mBtnLogin = findViewById(R.id.btn_login);
       mBtnSignUp = findViewById(R.id.btn_sign_up);
       mImgFacebook = findViewById(R.id.img_facebook);
       mImgTwitter = findViewById(R.id.img_twitter);
       mImgGoogle = findViewById(R.id.img_google_plus);

       mFacebookCallbackManager = CallbackManager.Factory.create();
       mFacebookLoginManager = LoginManager.getInstance();

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i(TAG,"request code = "+requestCode);
        mProgressDialog.dismiss();

        if (requestCode == CallbackManagerImpl.RequestCodeOffset.Login.toRequestCode())
        {
            if (resultCode == RESULT_OK)
            {
                Log.i(TAG,"onActivityResult() method called for facebook login");
                mFacebookCallbackManager.onActivityResult(requestCode, resultCode, data);
            }
        }

        if (requestCode == REQUEST_CODE_GOOGLE)
        {
            if (resultCode == RESULT_OK)
            {
                Log.i(TAG,"onActivityResult() method called for google login");
                com.google.android.gms.tasks.Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                GoogleSignInResult signInResult = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
               // handleGoogleLoginResult(task);
                handleGoogleLoginResult(signInResult);
            }

        }

    }


    private void handleGoogleLoginResult(GoogleSignInResult signAccount)
    {
        try
        {
           // GoogleSignInAccount account = task.getResult(ApiException.class);
            Log.i(TAG,"Logged in with google successfully");

            GoogleSignInAccount account = signAccount.getSignInAccount();
            if (account != null) {
                PreferenceHelper.setUserName(mContext, account.getDisplayName());
                PreferenceHelper.setUserEmail(mContext, account.getEmail());
                PreferenceHelper.setUserPicUri(mContext, account.getPhotoUrl().toString());
            }

           /* Log.i(TAG,"name = "+account.getDisplayName());
            Log.i(TAG,"email = "+account.getEmail());
            Log.i(TAG,"pic uri = "+account.getPhotoUrl());
*/
            startActivity(new Intent(mContext,MainActivity.class));
            finish();
        }
        catch (Exception e)
        {
            Log.e(TAG,"Exception in handleGoogleLoginResult() method , "+e.getMessage());
            e.printStackTrace();
        }
    }


    private void loginWithFacebook()
    {
        Log.i(TAG,"loginWithFacebook() method called ");
        try
        {
            mFacebookLoginManager.registerCallback(mFacebookCallbackManager, new FacebookCallback<LoginResult>()
            {
                @Override
                public void onSuccess(LoginResult loginResult)
                {
                    Log.i(TAG,"onSuccess() method called ");
                    final Profile profile = Profile.getCurrentProfile();
                    PreferenceHelper.setUserStatusLoggedIn(mContext);
                    UtilHelper.showSimpleDialog(mContext,"Congratulations","Logged In Successfully");

                    if (profile == null)
                    {
                       // Log.i(TAG,"profile is null");
                        mFacebookProfileTracker = new ProfileTracker()
                        {
                            @Override
                            protected void onCurrentProfileChanged(Profile oldProfile, Profile currentProfile)
                            {
                                PreferenceHelper.setUserName(mContext,currentProfile.getName());
                                PreferenceHelper.setUserPicUri(mContext,String.valueOf(currentProfile.getProfilePictureUri(200,150)));
                                mFacebookProfileTracker.stopTracking();
                            }

                        };
                    }
                    if (profile != null)
                    {
                        PreferenceHelper.setUserName(mContext,profile.getName());
                        PreferenceHelper.setUserPicUri(mContext,String.valueOf(profile.getProfilePictureUri(200,150)));
                    }

                    GraphRequest graphRequest = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                        @Override
                        public void onCompleted(JSONObject object, GraphResponse response) {
                            try
                            {
                                PreferenceHelper.setUserEmail(mContext,object.getString("email"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    Bundle bundle = new Bundle();
                    bundle.putString("fields","email");
                    graphRequest.setParameters(bundle);
                    graphRequest.executeAsync();

                }

                @Override
                public void onCancel() {
                    Log.i(TAG,"facebook login cancelled");

                }

                @Override
                public void onError(FacebookException error) {
                    Log.i(TAG,"facebook login error , "+error.getMessage());
                    error.printStackTrace();

                }
            });

            mFacebookLoginManager.logInWithReadPermissions(LoginSocialActivity.this, Arrays.asList("public_profile"));
        }
        catch (Exception e)
        {
            Log.e(TAG,"Error in loginWithFacebook() method , "+e.getMessage());
            e.printStackTrace();
        }

    }

    private void configureFacebookLogin()
    {
        /*FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);*/
    }

    private void configureGoogleLogin()
    {
        String googleClientId = getString(R.string.google_server_client_id);
        GoogleSignInOptions mGoogleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestServerAuthCode(googleClientId)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(mContext)
                .enableAutoManage(LoginSocialActivity.this, new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                        Log.i(TAG,"google connect failed");
                    }
                })
                .addApi(Auth.GOOGLE_SIGN_IN_API,mGoogleSignInOptions)
                .build();


        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setMessage("Signing in.......");

    }


    private void changeActivity()
    {
        startActivity(new Intent(mContext,MainActivity.class));
        finish();
    }





}
