package org.ctdworld.appraise.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.ctdworld.appraise.R;
import org.ctdworld.appraise.helpers.UtilHelper;

public class LoginActivity extends AppCompatActivity
{
    private static final String TAG = LoginActivity.class.getSimpleName();

    EditText mEditEmail, mEditPassword;
    Button mBtnLogin;
    TextView mTxtForgotPassword;
    CheckBox mCheckStaySignIn;
    String dialogTile = "Wait....", dialogMessage = "Coming soon";
    Toolbar mToolbar;
    TextView mToolbarTitle;
    Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        try
        {
            setContentView(R.layout.activity_login);
            init();
            setToolbar();
            setListeners();

        }
        catch(Exception e)
        {
            Log.i(TAG,"Error in onCreate() method , "+e.getMessage());
            e.printStackTrace();
        }
    }


    private void init()
    {
        mContext = this;
        mToolbar = findViewById(R.id.login_toolbar);
        mToolbarTitle = findViewById(R.id.toolbar_txt_title);
        mEditEmail = findViewById(R.id.edit_email);
        mEditPassword = findViewById(R.id.edit_password);
        mBtnLogin = findViewById(R.id.btn_login);
        mCheckStaySignIn = findViewById(R.id.check_stay_signed);
        mTxtForgotPassword = findViewById(R.id.login_forgot_password);
    }


    private void setToolbar() {
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        mToolbarTitle.setText("Log In");
       /* actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_left_arrow);*/
    }

    private void setListeners()
    {

        mTxtForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext,ActivityForgotPassword.class));
            }
        });


        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  UtilHelper.showSimpleDialog(context,dialogTile,dialogMessage);
                startActivity(new Intent(LoginActivity.this,MainActivity.class));
            }
        });

        mCheckStaySignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG,"isChecked =  "+mCheckStaySignIn.isChecked());
                if (mCheckStaySignIn.isChecked())
                    Log.i(TAG,"Checked");
                else
                    Log.i(TAG," not Checked");
            }
        });
    }

}
