package org.ctdworld.appraise.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import org.ctdworld.appraise.R;


public class ActivityRegister extends AppCompatActivity
{
    private static final String TAG = ActivityRegister.class.getSimpleName();

    TextView mTxtLogin;
    Toolbar mToolbar;
    TextView mToolbarTitle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();
        setListener();
        setToolbar();
    }

    private void setListener() {
        mTxtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ActivityRegister.this,LoginActivity.class));
            }
        });
    }

    private void init() {
        mTxtLogin = findViewById(R.id.txt_login);
        mToolbar = findViewById(R.id.toolbar);
        mToolbarTitle = findViewById(R.id.toolbar_txt_title);
    }

    private void setToolbar() {
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        mToolbarTitle.setText("Sign Up");
       /* actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_left_arrow);*/
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        /*if (item.getItemId() == android.R.id.home)
            onBackPressed();*/

        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
