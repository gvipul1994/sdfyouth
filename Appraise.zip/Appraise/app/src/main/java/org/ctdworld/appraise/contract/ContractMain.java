package org.ctdworld.appraise.contract;

import android.net.Uri;

public class ContractMain
{
    public interface Interacter
    {
        interface OnFinishedListener
        {
            void updateNavigationDrawerUi(String name, String email, String picUri);
        }
        void updateNavigationDrawerUi();
    }

    public interface Presenter
    {
      //  void changeFragment();
        void updateNavigationDrawerUi();
        void logOut();
    }

    public interface View
    {
        //void changeFragment();
        void updateNavigationDrawerUi(String name, String email, String picUri);
        void logOut();

    }
}
