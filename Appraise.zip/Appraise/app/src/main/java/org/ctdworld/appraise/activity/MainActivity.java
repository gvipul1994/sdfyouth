package org.ctdworld.appraise.activity;

import android.content.Context;
import android.net.Uri;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.ctdworld.appraise.R;
import org.ctdworld.appraise.bean.User;
import org.ctdworld.appraise.contract.ContractMain;
import org.ctdworld.appraise.helpers.PreferenceHelper;
import org.ctdworld.appraise.presenter.PresenterMain;

import java.net.URL;

public class MainActivity extends AppCompatActivity implements ContractMain.View
{
    private static final String TAG = MainActivity.class.getSimpleName();

    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    Toolbar toolbar;
    FragmentManager fragmentManager;
    NavigationView navigationView;
    View mNavigationHeaderLayout;
    ContractMain.Presenter mPresenter;
    Context mContext;

    ImageView mImgProfile;
    TextView mTxtNameProfile;




    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        try
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            init();
            setSupportActionBar(toolbar);
            prepareNavigationDrawer();

            mPresenter.updateNavigationDrawerUi();
        }
        catch (Exception e)
        {
            Log.e(TAG,"Exception in onCreate() method , "+e.getMessage());
            e.printStackTrace();
        }
    }



    private void init()
    {
        toolbar = findViewById(R.id.toolbar);
        fragmentManager = getSupportFragmentManager();
        navigationView = findViewById(R.id.navigation_view);
        drawerLayout = findViewById(R.id.drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close);
        mNavigationHeaderLayout = navigationView.getHeaderView(0);
        mPresenter = new PresenterMain(getApplicationContext(),this);

    }

    private void prepareNavigationDrawer()
    {
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset){}

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {
                Log.i(TAG,"Drawer opened");
            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {
                Log.i(TAG,"Drawer closed");
            }

            @Override
            public void onDrawerStateChanged(int newState) {}
        });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                item.setChecked(true);
                drawerLayout.closeDrawer(GravityCompat.START);

                switch (item.getItemId())
                {

                }

                return true;
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
               /* FragmentNavigationDrawer fragment = (FragmentNavigationDrawer) getSupportFragmentManager().findFragmentByTag(Const.Tag.FRAGMENT_NAVIGATION_DRAWER);
                if(fragment != null)
                    fragment.setDrawerListener(drawerLayout);
                else
                    Log.i(TAG,"fragment is null");*/
                break;
        }

        return true;
    }


    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START))
            drawerLayout.closeDrawer(GravityCompat.START);
        else
            super.onBackPressed();

    }



    @Override
    public void updateNavigationDrawerUi(String name, String email, String picUri)
    {
        /*Log.i(TAG,"onUpdateNavigationDrawerUi() method called ");
        mImgProfile = mNavigationHeaderLayout.findViewById(R.id.img_profile);
        mTxtNameProfile = mNavigationHeaderLayout.findViewById(R.id.txt_profile_name);

       // imgImage.setImageURI(picUri);
        Glide.with(this).load(picUri).into(mImgProfile);
     //   Glide.with(this).load("http://goo.gl/gEgYUd").into(imgImage);
        mTxtNameProfile.setText(name);*/
    }

    @Override
    public void logOut()
    {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build();
        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient(getApplicationContext(),gso);

            googleSignInClient.signOut()
            .addOnCompleteListener(MainActivity.this, new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Log.i(TAG,"Logged out successfully");

                    mImgProfile.setImageResource(R.drawable.img_profile_lady);
                    mTxtNameProfile.setText("");

                }
            });

        LoginManager loginManager = LoginManager.getInstance();
        loginManager.logOut();
        mImgProfile.setImageResource(R.drawable.img_profile_lady);
        mTxtNameProfile.setText("");

    }
}
