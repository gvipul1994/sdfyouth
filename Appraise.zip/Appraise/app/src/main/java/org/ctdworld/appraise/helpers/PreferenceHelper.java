package org.ctdworld.appraise.helpers;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.ListPreference;

import org.ctdworld.appraise.bean.User;

public class PreferenceHelper
{
    private static final String PREF_USER = "user";
    private static final String KEY_USER_LOGGED_IN_STATUS = "login status";
    private static final String KEY_USER_NAME = "name";
    private static final String KEY_USER_EMAIL = "email";
    private static final String KEY_USER_PIC_URI = "pic uri";


    public static void setUserName(Context context, String name)
    {
        SharedPreferences preferences = context.getSharedPreferences(PREF_USER,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_USER_NAME,name);
        editor.apply();
    }

    public static void setUserEmail(Context context,String email)
    {
        SharedPreferences preferences = context.getSharedPreferences(PREF_USER,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_USER_EMAIL,email);
        editor.apply();
    }

    public static void setUserPicUri(Context context,String picUri)
    {
        SharedPreferences preferences = context.getSharedPreferences(PREF_USER,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_USER_PIC_URI,picUri);
        editor.apply();
    }

    public static void setUserStatusLoggedIn(Context context)
    {
        SharedPreferences preferences = context.getSharedPreferences(PREF_USER,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(KEY_USER_LOGGED_IN_STATUS,true);
        editor.apply();
    }

    public static boolean isUserLoggedIn(Context context)
    {
        SharedPreferences preferences = context.getSharedPreferences(PREF_USER,Context.MODE_PRIVATE);
        return preferences.getBoolean(KEY_USER_LOGGED_IN_STATUS,false);
    }

    public static User getUserDetails(Context context)
    {
        User user = new User();
        SharedPreferences preferences = context.getSharedPreferences(PREF_USER,Context.MODE_PRIVATE);

        user.setName(preferences.getString(KEY_USER_NAME,""));
        user.setEmail(preferences.getString(KEY_USER_EMAIL,""));
        user.setPicUri(preferences.getString(KEY_USER_PIC_URI,""));

        return user;
    }

    public static void setUserLoggedOut(Context context)
    {
        SharedPreferences preferences = context.getSharedPreferences(PREF_USER,Context.MODE_PRIVATE);
        preferences.edit().clear().apply();
    }

}
