package org.ctdworld.appraise.helpers;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.ctdworld.appraise.R;

public class UtilHelper
{
    private static AlertDialog dialog;


    private static void showDialog(Context context,View layout)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(layout);

        dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }

    public static void showSimpleDialog(Context context, String title, String message)
    {
        LayoutInflater inflater = LayoutInflater.from(context);
        LinearLayout linearLayout = (LinearLayout) inflater.inflate(R.layout.layout_alert_dialog,null);

        TextView tvTitle = linearLayout.findViewById(R.id.tv_title_dailog);
        TextView tvMessage = linearLayout.findViewById(R.id.tv_message_dailog);
        Button button = linearLayout.findViewById(R.id.btn_dialog);

        tvTitle.setText(title);
        tvMessage.setText(message);
        button.setText("Ok");

       showDialog(context,linearLayout);

        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                hideDialog();
            }
        });
    }


    public static void hideDialog()
    {
        if (dialog != null)
        dialog.dismiss();
    }



}

